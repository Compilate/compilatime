import { PrismaClient, TimeEntry, TimeEntryType, TimeEntrySource } from '@prisma/client';
import { z } from 'zod';
import { cache } from '../../config/redis';

const prisma = new PrismaClient();

// Esquemas de validación
const createTimeEntrySchema = z.object({
    employeeId: z.string().min(1, 'El ID del empleado es requerido'),
    type: z.nativeEnum(TimeEntryType),
    timestamp: z.string().datetime('Timestamp inválido'),
    source: z.nativeEnum(TimeEntrySource).default(TimeEntrySource.WEB),
    location: z.string().optional(),
    deviceInfo: z.string().optional(),
    notes: z.string().optional(),
});

const updateTimeEntrySchema = z.object({
    type: z.nativeEnum(TimeEntryType).optional(),
    timestamp: z.string().datetime('Timestamp inválido').optional(),
    location: z.string().optional(),
    deviceInfo: z.string().optional(),
    notes: z.string().optional(),
});

const timeEntryFiltersSchema = z.object({
    employeeId: z.string().optional(),
    startDate: z.string().datetime('Fecha de inicio inválida').optional(),
    endDate: z.string().datetime('Fecha de fin inválida').optional(),
    type: z.nativeEnum(TimeEntryType).optional(),
    source: z.nativeEnum(TimeEntrySource).optional(),
    page: z.number().min(1, 'La página debe ser mayor a 0').default(1),
    limit: z.number().min(1, 'El límite debe ser mayor a 0').max(100, 'El límite máximo es 100').default(20),
});

const bulkCreateSchema = z.object({
    entries: z.array(createTimeEntrySchema).min(1, 'Debe proporcionar al menos un registro'),
});

// Tipos
type CreateTimeEntryData = z.infer<typeof createTimeEntrySchema>;
type UpdateTimeEntryData = z.infer<typeof updateTimeEntrySchema>;
type TimeEntryFilters = z.infer<typeof timeEntryFiltersSchema>;
type BulkCreateData = z.infer<typeof bulkCreateSchema>;

// Servicio de gestión de registros de tiempo
export class TimeEntryService {
    // Crear nuevo registro de tiempo
    static async createTimeEntry(companyId: string, data: CreateTimeEntryData): Promise<TimeEntry> {
        try {
            // Validar datos
            const validatedData = createTimeEntrySchema.parse(data);

            // Verificar si el empleado existe y está activo
            const employee = await prisma.employee.findFirst({
                where: {
                    id: validatedData.employeeId,
                    companyId,
                    active: true,
                },
            });

            if (!employee) {
                throw new Error('Empleado no encontrado o no está activo');
            }

            // Validar reglas de fichaje
            await this.validatePunchRules(companyId, validatedData.employeeId, validatedData.type, validatedData.timestamp);

            // Crear registro
            const timeEntry = await prisma.timeEntry.create({
                data: {
                    companyId,
                    employeeId: validatedData.employeeId,
                    type: validatedData.type,
                    timestamp: new Date(validatedData.timestamp),
                    source: validatedData.source,
                    location: validatedData.location,
                    deviceInfo: validatedData.deviceInfo,
                    notes: validatedData.notes,
                    createdByEmployee: true,
                },
            });

            // Actualizar WorkDay si es necesario
            await this.updateWorkDay(companyId, validatedData.employeeId, new Date(validatedData.timestamp));

            // Limpiar caché
            await cache.clearPattern(`time-entries:${companyId}:*`);
            await cache.clearPattern(`work-days:${companyId}:*`);

            console.log(`✅ Registro de tiempo creado: ${employee.name} - ${validatedData.type}`);
            return timeEntry;
        } catch (error) {
            console.error('❌ Error creando registro de tiempo:', error);
            throw error;
        }
    }

    // Fichaje rápido (para empleados)
    static async punchTime(
        companyId: string,
        employeeId: string,
        type: TimeEntryType,
        timestamp?: string,
        source: TimeEntrySource = TimeEntrySource.WEB,
        location?: string,
        deviceInfo?: string
    ): Promise<TimeEntry> {
        try {
            const punchData: CreateTimeEntryData = {
                employeeId,
                type,
                timestamp: timestamp || new Date().toISOString(),
                source,
                location,
                deviceInfo,
            };

            return await this.createTimeEntry(companyId, punchData);
        } catch (error) {
            console.error('❌ Error en punchTime:', error);
            throw error;
        }
    }

    // Obtener registro por ID
    static async getTimeEntryById(companyId: string, entryId: string): Promise<TimeEntry | null> {
        try {
            const timeEntry = await prisma.timeEntry.findFirst({
                where: {
                    id: entryId,
                    companyId,
                },
                include: {
                    employee: {
                        select: {
                            id: true,
                            name: true,
                            surname: true,
                            dni: true,
                        },
                    },
                    editLogs: {
                        include: {
                            companyUser: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true,
                                },
                            },
                        },
                        orderBy: { createdAt: 'desc' },
                    },
                },
            });

            return timeEntry;
        } catch (error) {
            console.error(`❌ Error obteniendo registro ${entryId}:`, error);
            throw error;
        }
    }

    // Obtener registros con filtros
    static async getTimeEntries(companyId: string, filters: TimeEntryFilters) {
        try {
            const {
                employeeId,
                startDate,
                endDate,
                type,
                source,
                page = 1,
                limit = 20,
            } = filters;

            const skip = (page - 1) * limit;

            // Construir filtro where
            const where: any = { companyId };

            if (employeeId) {
                where.employeeId = employeeId;
            }

            if (startDate || endDate) {
                where.timestamp = {};
                if (startDate) {
                    where.timestamp.gte = new Date(startDate);
                }
                if (endDate) {
                    where.timestamp.lte = new Date(endDate);
                }
            }

            if (type) {
                where.type = type;
            }

            if (source) {
                where.source = source;
            }

            const [timeEntries, total] = await Promise.all([
                prisma.timeEntry.findMany({
                    where,
                    skip,
                    take: limit,
                    orderBy: { timestamp: 'desc' },
                    include: {
                        employee: {
                            select: {
                                id: true,
                                name: true,
                                surname: true,
                                dni: true,
                            },
                        },
                    },
                }),
                prisma.timeEntry.count({ where }),
            ]);

            return {
                timeEntries,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            };
        } catch (error) {
            console.error(`❌ Error obteniendo registros de empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Actualizar registro de tiempo
    static async updateTimeEntry(
        companyId: string,
        entryId: string,
        companyUserId: string,
        data: UpdateTimeEntryData,
        reason: string
    ): Promise<TimeEntry> {
        try {
            // Validar datos
            const validatedData = updateTimeEntrySchema.parse(data);

            // Obtener registro actual
            const existingEntry = await prisma.timeEntry.findFirst({
                where: {
                    id: entryId,
                    companyId,
                },
            });

            if (!existingEntry) {
                throw new Error('Registro no encontrado');
            }

            // Guardar log de auditoría
            await prisma.timeEntryEditLog.create({
                data: {
                    timeEntryId: entryId,
                    companyUserId,
                    oldTimestamp: existingEntry.timestamp,
                    newTimestamp: validatedData.timestamp ? new Date(validatedData.timestamp) : existingEntry.timestamp,
                    reason,
                },
            });

            // Actualizar registro
            const updatedEntry = await prisma.timeEntry.update({
                where: {
                    id: entryId,
                    companyId,
                },
                data: {
                    ...validatedData,
                    approvedBy: companyUserId,
                    approvedAt: new Date(),
                },
            });

            // Actualizar WorkDay si cambió el timestamp
            if (validatedData.timestamp) {
                await this.updateWorkDay(companyId, existingEntry.employeeId, new Date(validatedData.timestamp));
            }

            // Limpiar caché
            await cache.clearPattern(`time-entry:${entryId}*`);
            await cache.clearPattern(`time-entries:${companyId}:*`);

            console.log(`✅ Registro de tiempo actualizado: ${entryId}`);
            return updatedEntry;
        } catch (error) {
            console.error(`❌ Error actualizando registro ${entryId}:`, error);
            throw error;
        }
    }

    // Eliminar registro de tiempo
    static async deleteTimeEntry(companyId: string, entryId: string, companyUserId: string, reason: string): Promise<void> {
        try {
            // Obtener registro actual
            const existingEntry = await prisma.timeEntry.findFirst({
                where: {
                    id: entryId,
                    companyId,
                },
            });

            if (!existingEntry) {
                throw new Error('Registro no encontrado');
            }

            // Guardar log de auditoría
            await prisma.timeEntryEditLog.create({
                data: {
                    timeEntryId: entryId,
                    companyUserId,
                    oldTimestamp: existingEntry.timestamp,
                    newTimestamp: new Date(), // Timestamp de eliminación
                    reason: `Registro eliminado: ${reason}`,
                },
            });

            await prisma.timeEntry.delete({
                where: {
                    id: entryId,
                    companyId,
                },
            });

            // Actualizar WorkDay
            await this.updateWorkDay(companyId, existingEntry.employeeId, new Date());

            // Limpiar caché
            await cache.clearPattern(`time-entry:${entryId}*`);
            await cache.clearPattern(`time-entries:${companyId}:*`);

            console.log(`✅ Registro de tiempo eliminado: ${entryId}`);
        } catch (error) {
            console.error(`❌ Error eliminando registro ${entryId}:`, error);
            throw error;
        }
    }

    // Creación masiva de registros
    static async bulkCreateTimeEntries(companyId: string, data: BulkCreateData): Promise<TimeEntry[]> {
        try {
            const validatedData = bulkCreateSchema.parse(data);

            // Verificar que todos los empleados existen
            const employeeIds = validatedData.entries.map(e => e.employeeId);
            const employees = await prisma.employee.findMany({
                where: {
                    id: { in: employeeIds },
                    companyId,
                    active: true,
                },
            });

            if (employees.length !== employeeIds.length) {
                throw new Error('Algunos empleados no existen o no están activos');
            }

            // Crear registros en lote
            const timeEntries = await prisma.timeEntry.createMany({
                data: validatedData.entries.map(entry => ({
                    companyId,
                    employeeId: entry.employeeId,
                    type: entry.type,
                    timestamp: new Date(entry.timestamp),
                    source: entry.source || TimeEntrySource.ADMIN,
                    location: entry.location,
                    deviceInfo: entry.deviceInfo,
                    notes: entry.notes,
                    createdByEmployee: false,
                })),
            });

            // Actualizar WorkDays para cada empleado
            const employeeGroups = validatedData.entries.reduce((groups, entry) => {
                if (!groups[entry.employeeId]) {
                    groups[entry.employeeId] = [];
                }
                groups[entry.employeeId].push(new Date(entry.timestamp));
                return groups;
            }, {} as Record<string, Date[]>);

            for (const [employeeId, dates] of Object.entries(employeeGroups)) {
                for (const date of dates) {
                    await this.updateWorkDay(companyId, employeeId, date);
                }
            }

            // Limpiar caché
            await cache.clearPattern(`time-entries:${companyId}:*`);
            await cache.clearPattern(`work-days:${companyId}:*`);

            console.log(`✅ ${validatedData.entries.length} registros creados en lote`);
            return timeEntries as any;
        } catch (error) {
            console.error('❌ Error en creación masiva de registros:', error);
            throw error;
        }
    }

    // Obtener registros de un empleado
    static async getEmployeeTimeEntries(companyId: string, employeeId: string, filters: Omit<TimeEntryFilters, 'employeeId'>) {
        try {
            return await this.getTimeEntries(companyId, {
                ...filters,
                employeeId,
            });
        } catch (error) {
            console.error(`❌ Error obteniendo registros del empleado ${employeeId}:`, error);
            throw error;
        }
    }

    // Obtener resumen diario
    static async getDailySummary(companyId: string, date: string): Promise<any> {
        try {
            const cacheKey = `daily-summary:${companyId}:${date}`;
            const cached = await cache.get(cacheKey);

            if (cached) {
                return JSON.parse(cached);
            }

            const targetDate = new Date(date);
            const startOfDay = new Date(targetDate.setHours(0, 0, 0, 0));
            const endOfDay = new Date(targetDate.setHours(23, 59, 59, 999));

            const [entries, totalEntries] = await Promise.all([
                prisma.timeEntry.findMany({
                    where: {
                        companyId,
                        timestamp: {
                            gte: startOfDay,
                            lte: endOfDay,
                        },
                    },
                    include: {
                        employee: {
                            select: {
                                id: true,
                                name: true,
                                surname: true,
                                dni: true,
                            },
                        },
                    },
                    orderBy: { timestamp: 'asc' },
                }),
                prisma.timeEntry.count({
                    where: {
                        companyId,
                        timestamp: {
                            gte: startOfDay,
                            lte: endOfDay,
                        },
                    },
                }),
            ]);

            // Agrupar por empleado
            const employeeSummaries = entries.reduce((summaries, entry) => {
                const empId = entry.employeeId;
                if (!summaries[empId]) {
                    summaries[empId] = {
                        employee: entry.employee,
                        entries: [],
                        totalMinutes: 0,
                        firstEntry: null,
                        lastEntry: null,
                    };
                }

                summaries[empId].entries.push(entry);
                summaries[empId].totalMinutes += this.calculateMinutesWorked(summaries[empId].entries);

                if (!summaries[empId].firstEntry || entry.timestamp < summaries[empId].firstEntry.timestamp) {
                    summaries[empId].firstEntry = entry;
                }
                if (!summaries[empId].lastEntry || entry.timestamp > summaries[empId].lastEntry.timestamp) {
                    summaries[empId].lastEntry = entry;
                }

                return summaries;
            }, {} as Record<string, any>);

            const summary = {
                date,
                totalEntries,
                employees: Object.values(employeeSummaries),
            };

            // Guardar en caché por 5 minutos
            await cache.set(cacheKey, JSON.stringify(summary), 300);

            return summary;
        } catch (error) {
            console.error(`❌ Error obteniendo resumen diario ${date}:`, error);
            throw error;
        }
    }

    // Obtener estadísticas de fichajes
    static async getTimeEntryStats(companyId: string, filters: { startDate?: string; endDate?: string } = {}): Promise<any> {
        try {
            const cacheKey = `time-stats:${companyId}:${JSON.stringify(filters)}`;
            const cached = await cache.get(cacheKey);

            if (cached) {
                return JSON.parse(cached);
            }

            const where: any = { companyId };

            if (filters.startDate || filters.endDate) {
                where.timestamp = {};
                if (filters.startDate) {
                    where.timestamp.gte = new Date(filters.startDate);
                }
                if (filters.endDate) {
                    where.timestamp.lte = new Date(filters.endDate);
                }
            }

            const [
                totalEntries,
                entriesByType,
                entriesBySource,
                recentEntries,
            ] = await Promise.all([
                prisma.timeEntry.count({ where }),
                prisma.timeEntry.groupBy({
                    by: ['type'],
                    where,
                    _count: true,
                }),
                prisma.timeEntry.groupBy({
                    by: ['source'],
                    where,
                    _count: true,
                }),
                prisma.timeEntry.findMany({
                    where,
                    orderBy: { timestamp: 'desc' },
                    take: 10,
                    include: {
                        employee: {
                            select: {
                                name: true,
                                surname: true,
                            },
                        },
                    },
                }),
            ]);

            const stats = {
                total: totalEntries,
                byType: entriesByType.reduce((acc: any, item: any) => {
                    acc[item.type] = item._count;
                    return acc;
                }, {}),
                bySource: entriesBySource.reduce((acc: any, item: any) => {
                    acc[item.source] = item._count;
                    return acc;
                }, {}),
                recent: recentEntries,
            };

            // Guardar en caché por 10 minutos
            await cache.set(cacheKey, JSON.stringify(stats), 600);

            return stats;
        } catch (error) {
            console.error(`❌ Error obteniendo estadísticas de fichajes ${companyId}:`, error);
            throw error;
        }
    }

    // Métodos auxiliares
    private static async validatePunchRules(companyId: string, employeeId: string, type: TimeEntryType, timestamp: string): Promise<void> {
        try {
            const now = new Date(timestamp);
            const today = now.toISOString().split('T')[0];

            // Obtener último registro del empleado hoy
            const lastEntry = await prisma.timeEntry.findFirst({
                where: {
                    employeeId,
                    companyId,
                    timestamp: {
                        gte: new Date(today),
                    },
                },
                orderBy: { timestamp: 'desc' },
            });

            // Validar reglas de fichaje
            if (lastEntry) {
                // No permitir dos entradas seguidas
                if (lastEntry.type === TimeEntryType.IN && type === TimeEntryType.IN) {
                    throw new Error('Ya tienes una entrada registrada hoy. Debes registrar una salida primero.');
                }

                // No permitir dos salidas seguidas
                if (lastEntry.type === TimeEntryType.OUT && type === TimeEntryType.OUT) {
                    throw new Error('Ya tienes una salida registrada hoy. Debes registrar una entrada primero.');
                }

                // No permitir BREAK sin IN previo
                if (type === TimeEntryType.BREAK && lastEntry.type !== TimeEntryType.IN) {
                    throw new Error('Debes registrar una entrada antes de iniciar una pausa.');
                }

                // No permitir RESUME sin BREAK previo
                if (type === TimeEntryType.RESUME && lastEntry.type !== TimeEntryType.BREAK) {
                    throw new Error('Debes registrar una pausa antes de reanudar.');
                }
            }
        } catch (error) {
            console.error('❌ Error validando reglas de fichaje:', error);
            throw error;
        }
    }

    private static async updateWorkDay(companyId: string, employeeId: string, date: Date): Promise<void> {
        try {
            const workDayDate = date.toISOString().split('T')[0]; // YYYY-MM-DD

            // Obtener o crear WorkDay
            let workDay = await prisma.workDay.findFirst({
                where: {
                    companyId,
                    employeeId,
                    date: new Date(workDayDate),
                },
            });

            const entries = await prisma.timeEntry.findMany({
                where: {
                    employeeId,
                    companyId,
                    timestamp: {
                        gte: new Date(workDayDate),
                        lt: new Date(date.getTime() + 24 * 60 * 60 * 1000), // Siguiente día
                    },
                },
                orderBy: { timestamp: 'asc' },
            });

            if (entries.length === 0) return;

            // Calcular horas trabajadas
            const { workedMinutes, overtimeMinutes } = this.calculateMinutesWorked(entries);

            if (!workDay) {
                workDay = await prisma.workDay.create({
                    data: {
                        companyId,
                        employeeId,
                        date: new Date(workDayDate),
                        startTime: entries[0]?.timestamp,
                        endTime: entries[entries.length - 1]?.timestamp,
                        workedMinutes,
                        overtimeMinutes,
                        status: 'PENDING',
                    },
                });
            } else {
                workDay = await prisma.workDay.update({
                    where: { id: workDay.id },
                    data: {
                        startTime: entries[0]?.timestamp,
                        endTime: entries[entries.length - 1]?.timestamp,
                        workedMinutes,
                        overtimeMinutes,
                    },
                });
            }

            console.log(`✅ WorkDay actualizado: ${employeeId} - ${workDayDate}`);
        } catch (error) {
            console.error(`❌ Error actualizando WorkDay:`, error);
            throw error;
        }
    }

    private static calculateMinutesWorked(entries: any[]): { workedMinutes: number; overtimeMinutes: number } {
        let totalMinutes = 0;
        let inTime: Date | null = null;
        let breakMinutes = 0;

        for (const entry of entries) {
            if (entry.type === TimeEntryType.IN) {
                inTime = entry.timestamp;
            } else if (entry.type === TimeEntryType.OUT && inTime) {
                totalMinutes += (entry.timestamp.getTime() - inTime.getTime()) / (1000 * 60);
                inTime = null;
            } else if (entry.type === TimeEntryType.BREAK && inTime) {
                breakMinutes += 5; // Suponemos 5 minutos de pausa por defecto
            } else if (entry.type === TimeEntryType.RESUME && inTime) {
                inTime = entry.timestamp;
            }
        }

        // Calcular horas extras (más de 8 horas diarias)
        const regularMinutes = 8 * 60; // 8 horas = 480 minutos
        const overtimeMinutes = Math.max(0, totalMinutes - regularMinutes);

        return { workedMinutes: totalMinutes, overtimeMinutes };
    }

}

export default TimeEntryService;