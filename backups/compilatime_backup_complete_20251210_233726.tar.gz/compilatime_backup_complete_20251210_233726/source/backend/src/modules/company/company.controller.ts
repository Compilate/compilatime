import { Request, Response } from 'express';
import { z } from 'zod';
import CompanyService from './company.service';

// Esquemas de validación para las peticiones
const createCompanySchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
    slug: z.string().min(2, 'El código debe tener al menos 2 caracteres')
        .regex(/^[a-z0-9-]+$/, 'El código solo puede contener letras minúsculas, números y guiones'),
    email: z.string().email('Email inválido'),
    adminName: z.string().min(2, 'El nombre del administrador debe tener al menos 2 caracteres'),
    adminEmail: z.string().email('Email del administrador inválido'),
    adminPassword: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
    plan: z.enum(['FREE', 'BASIC', 'PRO', 'ENTERPRISE']).default('BASIC'),
});

const updateCompanySchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres').optional(),
    email: z.string().email('Email inválido').optional(),
    phone: z.string().optional(),
    address: z.string().optional(),
    city: z.string().optional(),
    province: z.string().optional(),
    postalCode: z.string().optional(),
    country: z.string().optional(),
    taxId: z.string().optional(),
    logo: z.string().url('URL del logo inválida').optional(),
    website: z.string().url('URL del sitio web inválida').optional(),
    description: z.string().optional(),
});

const updateConfigSchema = z.object({
    timezone: z.string().optional(),
    dateFormat: z.string().optional(),
    timeFormat: z.enum(['12h', '24h']).optional(),
    currency: z.string().optional(),
    language: z.string().optional(),
    workingDays: z.array(z.number()).optional(),
    workingHours: z.object({
        start: z.string(),
        end: z.string(),
    }).optional(),
    overtimeRules: z.object({
        enabled: z.boolean(),
        dailyThreshold: z.number(),
        weeklyThreshold: z.number(),
        rate: z.number(),
    }).optional(),
    notifications: z.object({
        emailEnabled: z.boolean(),
        pushEnabled: z.boolean(),
        smsEnabled: z.boolean(),
    }).optional(),
    security: z.object({
        passwordMinLength: z.number(),
        sessionTimeout: z.number(),
        maxLoginAttempts: z.number(),
        twoFactorEnabled: z.boolean(),
    }).optional(),
});

const inviteUserSchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
    email: z.string().email('Email inválido'),
    role: z.enum(['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'SUPERVISOR', 'HR']),
    permissions: z.array(z.string()).optional(),
});

// const activateUserSchema = z.object({
//     token: z.string().min(1, 'El token es requerido'),
//     password: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
// });

class CompanyController {
    // Crear nueva empresa
    static async createCompany(req: Request, res: Response) {
        try {
            const validatedData = createCompanySchema.parse(req.body);
            const company = await CompanyService.createCompany(validatedData);

            res.status(201).json({
                success: true,
                message: 'Empresa creada exitosamente',
                data: company,
            });
        } catch (error: any) {
            console.error('❌ Error en createCompany:', error);

            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    success: false,
                    message: 'Datos inválidos',
                    errors: error.errors,
                });
            }

            res.status(500).json({
                success: false,
                message: error.message || 'Error al crear la empresa',
            });
        }
    }

    // Obtener empresa por ID
    static async getCompany(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const company = await CompanyService.getCompanyById(id);

            if (!company) {
                return res.status(404).json({
                    success: false,
                    message: 'Empresa no encontrada',
                });
            }

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para ver esta empresa',
                });
            }

            res.json({
                success: true,
                data: company,
            });
        } catch (error: any) {
            console.error('❌ Error en getCompany:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al obtener la empresa',
            });
        }
    }

    // Obtener empresa por slug
    static async getCompanyBySlug(req: Request, res: Response) {
        try {
            const { slug } = req.params;
            const company = await CompanyService.getCompanyBySlug(slug);

            if (!company) {
                return res.status(404).json({
                    success: false,
                    message: 'Empresa no encontrada',
                });
            }

            res.json({
                success: true,
                data: company,
            });
        } catch (error: any) {
            console.error('❌ Error en getCompanyBySlug:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al obtener la empresa',
            });
        }
    }

    // Actualizar empresa
    static async updateCompany(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const validatedData = updateCompanySchema.parse(req.body);

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para actualizar esta empresa',
                });
            }

            const company = await CompanyService.updateCompany(id, validatedData);

            res.json({
                success: true,
                message: 'Empresa actualizada exitosamente',
                data: company,
            });
        } catch (error: any) {
            console.error('❌ Error en updateCompany:', error);

            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    success: false,
                    message: 'Datos inválidos',
                    errors: error.errors,
                });
            }

            res.status(500).json({
                success: false,
                message: error.message || 'Error al actualizar la empresa',
            });
        }
    }

    // Actualizar configuración de la empresa
    static async updateConfig(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const validatedData = updateConfigSchema.parse(req.body);

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para actualizar esta configuración',
                });
            }

            const config = await CompanyService.updateCompanyConfig(id, validatedData);

            res.json({
                success: true,
                message: 'Configuración actualizada exitosamente',
                data: config,
            });
        } catch (error: any) {
            console.error('❌ Error en updateConfig:', error);

            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    success: false,
                    message: 'Datos inválidos',
                    errors: error.errors,
                });
            }

            res.status(500).json({
                success: false,
                message: error.message || 'Error al actualizar la configuración',
            });
        }
    }

    // Obtener usuarios de la empresa
    static async getUsers(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const page = parseInt(req.query.page as string) || 1;
            const limit = parseInt(req.query.limit as string) || 20;

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para ver los usuarios de esta empresa',
                });
            }

            const result = await CompanyService.getCompanyUsers(id, page, limit);

            res.json({
                success: true,
                data: result,
            });
        } catch (error: any) {
            console.error('❌ Error en getUsers:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al obtener los usuarios',
            });
        }
    }

    // Invitar usuario a la empresa
    static async inviteUser(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const validatedData = inviteUserSchema.parse(req.body);

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para invitar usuarios a esta empresa',
                });
            }

            const user = await CompanyService.inviteUser(id, validatedData);

            res.status(201).json({
                success: true,
                message: 'Usuario invitado exitosamente',
                data: user,
            });
        } catch (error: any) {
            console.error('❌ Error en inviteUser:', error);

            if (error instanceof z.ZodError) {
                return res.status(400).json({
                    success: false,
                    message: 'Datos inválidos',
                    errors: error.errors,
                });
            }

            res.status(500).json({
                success: false,
                message: error.message || 'Error al invitar al usuario',
            });
        }
    }

    // Activar usuario invitado (temporalmente deshabilitado)
    static async activateUser(_req: Request, res: Response) {
        try {
            res.json({
                success: false,
                message: 'Funcionalidad temporalmente deshabilitada. Por favor, contacta con el administrador.',
            });
        } catch (error: any) {
            console.error('❌ Error en activateUser:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al activar el usuario',
            });
        }
    }

    // Desactivar usuario
    static async deactivateUser(req: Request & { user?: any }, res: Response) {
        try {
            const { id, userId } = req.params;

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para desactivar usuarios de esta empresa',
                });
            }

            const user = await CompanyService.deactivateUser(id, userId);

            res.json({
                success: true,
                message: 'Usuario desactivado exitosamente',
                data: user,
            });
        } catch (error: any) {
            console.error('❌ Error en deactivateUser:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al desactivar el usuario',
            });
        }
    }

    // Eliminar usuario
    static async deleteUser(req: Request & { user?: any }, res: Response) {
        try {
            const { id, userId } = req.params;

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para eliminar usuarios de esta empresa',
                });
            }

            await CompanyService.deleteUser(id, userId);

            res.json({
                success: true,
                message: 'Usuario eliminado exitosamente',
            });
        } catch (error: any) {
            console.error('❌ Error en deleteUser:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al eliminar el usuario',
            });
        }
    }

    // Obtener suscripción de la empresa
    static async getSubscription(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para ver la suscripción de esta empresa',
                });
            }

            const subscription = await CompanyService.getCompanySubscription(id);

            res.json({
                success: true,
                data: subscription,
            });
        } catch (error: any) {
            console.error('❌ Error en getSubscription:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al obtener la suscripción',
            });
        }
    }

    // Actualizar suscripción
    static async updateSubscription(req: Request & { user?: any }, res: Response) {
        try {
            const { id } = req.params;
            const { plan } = req.body;

            if (!plan) {
                return res.status(400).json({
                    success: false,
                    message: 'El plan es requerido',
                });
            }

            // Verificar que el usuario pertenezca a la empresa
            if (req.user?.companyId !== id) {
                return res.status(403).json({
                    success: false,
                    message: 'No tienes permisos para actualizar la suscripción de esta empresa',
                });
            }

            const subscription = await CompanyService.updateSubscription(id, plan);

            res.json({
                success: true,
                message: 'Suscripción actualizada exitosamente',
                data: subscription,
            });
        } catch (error: any) {
            console.error('❌ Error en updateSubscription:', error);
            res.status(500).json({
                success: false,
                message: error.message || 'Error al actualizar la suscripción',
            });
        }
    }
}

export default CompanyController;