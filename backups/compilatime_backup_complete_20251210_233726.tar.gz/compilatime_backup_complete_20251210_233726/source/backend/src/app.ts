import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { config } from './config/env';
import { errorHandler, notFoundHandler } from './middlewares/errorHandler';
import { generalLimiter } from './middlewares/rateLimit';

// Importar rutas
import authRoutes from './modules/auth/auth.routes';
import timeEntryRoutes from './modules/timeEntry/timeEntry.routes';
import employeeRoutes from './modules/employee/employee.routes';
import scheduleRoutes from './modules/schedule/schedule.routes';
import dashboardRoutes from './modules/dashboard/dashboard.routes';
import { weeklyScheduleRoutes } from './modules/weeklySchedule/weeklySchedule.routes';
import reportsRoutes from './modules/reports/reports.routes';

// Crear aplicación Express
const app = express();

// Middleware de seguridad
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
    crossOriginEmbedderPolicy: false,
}));

// Configurar CORS
app.use(cors({
    origin: config.cors.origin,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
}));

// Middleware para parsear JSON y cookies
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Rate limiting general
app.use(generalLimiter);

// Middleware para logging de requests (solo en desarrollo)
if (config.isDevelopment) {
    app.use((req, _res, next) => {
        console.log(`📝 ${req.method} ${req.path} - ${new Date().toISOString()}`);
        next();
    });
}

// Ruta raíz para health check
app.get('/', (_req, res) => {
    res.json({
        message: 'CompilaTime API - Sistema de Registro Horario',
        version: '1.0.0',
        status: 'running',
        timestamp: new Date().toISOString(),
        endpoints: {
            auth: '/api/auth',
            timeEntries: '/api/time-entries',
            health: '/health'
        }
    });
});

// Rutas de la API
app.use('/api/auth', authRoutes);
app.use('/api/time-entries', timeEntryRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/schedules', scheduleRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/weekly-schedules', weeklyScheduleRoutes);
app.use('/api/reports', reportsRoutes);

// Ruta de salud del sistema
app.get('/health', (_req, res) => {
    res.status(200).json({
        success: true,
        message: 'CompilaTime API is running',
        timestamp: new Date().toISOString(),
        environment: config.isDevelopment ? 'development' : config.isProduction ? 'production' : 'test',
        version: '1.0.0',
    });
});

// Ruta de información de la API
app.get('/api', (_req, res) => {
    res.status(200).json({
        success: true,
        message: 'CompilaTime API',
        version: '1.0.0',
        endpoints: {
            auth: '/api/auth',
            timeEntries: '/api/time-entries',
            employees: '/api/employees',
            schedules: '/api/schedules',
            dashboard: '/api/dashboard',
            weeklySchedules: '/api/weekly-schedules',
            reports: '/api/reports',
        },
        documentation: '/api/docs',
    });
});

// Manejo de rutas no encontradas
app.use(notFoundHandler);

// Middleware de manejo de errores
app.use(errorHandler);

export default app;