import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { formatDate } from '../../lib/utils';

const PerfilEmpleadoPage: React.FC = () => {
    const { employee } = useAuth();

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Mi Perfil</h1>
                <p className="text-gray-600">
                    Consulta tus datos personales y tu información de empleado.
                </p>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                    <h2 className="text-lg font-semibold text-gray-900">Datos Personales</h2>
                </div>
                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Nombre Completo
                            </label>
                            <p className="text-gray-900">
                                {employee?.name} {employee?.surname}
                            </p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                DNI
                            </label>
                            <p className="text-gray-900">{employee?.dni}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Email
                            </label>
                            <p className="text-gray-900">{employee?.email || 'No especificado'}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Teléfono
                            </label>
                            <p className="text-gray-900">{employee?.phone || 'No especificado'}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Departamento
                            </label>
                            <p className="text-gray-900">{employee?.department || 'No asignado'}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Posición
                            </label>
                            <p className="text-gray-900">{employee?.position || 'No asignada'}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Tipo de Contrato
                            </label>
                            <p className="text-gray-900">{employee?.contractType || 'No especificado'}</p>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Fecha de Contratación
                            </label>
                            <p className="text-gray-900">
                                {employee?.hireDate ? formatDate(employee.hireDate) : 'No especificada'}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                <div className="text-center">
                    <div className="text-gray-400 text-lg mb-2">👤</div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                        Zona Personal
                    </h3>
                    <p className="text-gray-500 mb-4">
                        Esta sección está en desarrollo. Próximamente podrás:
                    </p>
                    <ul className="text-left text-gray-600 space-y-2 max-w-md mx-auto">
                        <li>• Ver tu historial de fichajes completo</li>
                        <li>• Descargar informes mensuales</li>
                        <li>• Solicitar permisos y vacaciones</li>
                        <li>• Actualizar tus datos personales</li>
                        <li>• Cambiar tu PIN de acceso</li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default PerfilEmpleadoPage;