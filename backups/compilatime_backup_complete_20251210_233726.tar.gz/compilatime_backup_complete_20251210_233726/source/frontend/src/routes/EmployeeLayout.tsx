import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Outlet } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import FicharPage from '../pages/employee/FicharPage';
import PerfilEmpleadoPage from '../pages/employee/PerfilEmpleadoPage';
import MisRegistrosPage from '../pages/employee/MisRegistrosPage';
import HorarioPage from '../pages/employee/HorarioPage';
import EmployeeSidebar from '../components/employee/EmployeeSidebar';

const EmployeeLayout: React.FC = () => {
    const { isAuthenticated, employee } = useAuth();

    if (!isAuthenticated) {
        return <div>Cargando...</div>;
    }

    return (
        <div className="min-h-screen bg-gray-50 flex">
            {/* Sidebar para empleados */}
            <EmployeeSidebar />

            {/* Main content */}
            <main className="flex-1">
                {/* Header simple para empleados */}
                <header className="bg-white shadow-sm border-b border-gray-200">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div className="flex justify-between items-center h-16">
                            <div className="flex items-center">
                                <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                                    <span className="text-white font-bold text-sm">CT</span>
                                </div>
                                <span className="ml-2 text-xl font-semibold text-gray-900">CompilaTime</span>
                            </div>

                            <div className="flex items-center space-x-4">
                                <span className="text-sm text-gray-600">
                                    Bienvenido, {employee?.name}
                                </span>
                                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                                    <span className="text-sm font-medium text-gray-700">
                                        {employee?.name?.charAt(0).toUpperCase()}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <div className="py-6">
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <Routes>
                            <Route path="/empleado/fichar" element={<FicharPage />} />
                            <Route path="/empleado/perfil" element={<PerfilEmpleadoPage />} />
                            <Route path="/empleado/mis-registros" element={<MisRegistrosPage />} />
                            <Route path="/empleado/horario" element={<HorarioPage />} />
                        </Routes>
                        <Outlet />
                    </div>
                </div>
            </main>
        </div>
    );
};

export default EmployeeLayout;