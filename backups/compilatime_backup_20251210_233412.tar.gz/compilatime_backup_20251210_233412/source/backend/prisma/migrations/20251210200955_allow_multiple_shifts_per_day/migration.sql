-- DropIndex
DROP INDEX "weekly_schedules_companyId_employeeId_weekStart_dayOfWeek_key";
