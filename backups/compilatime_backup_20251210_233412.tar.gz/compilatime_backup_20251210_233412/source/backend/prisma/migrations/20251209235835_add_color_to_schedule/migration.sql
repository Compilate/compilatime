-- AlterTable
ALTER TABLE "schedules" ADD COLUMN     "color" TEXT;
