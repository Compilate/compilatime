import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import EmployeeController from './employee.controller';
import { authenticateToken, requireCompanyUser, requireEmployee } from '../../middlewares/authMiddleware';

const router = Router();

// Rate limiting para operaciones sensibles
const sensitiveLimit = rateLimit({
    windowMs: 60 * 1000, // 1 minuto
    max: 10, // máximo 10 intentos por minuto
    message: {
        success: false,
        message: 'Demasiados intentos. Por favor, espere un momento.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Rate limiting para creación de empleados
const createLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: 20, // máximo 20 empleados creados por 15 minutos
    message: {
        success: false,
        message: 'Demasiados intentos de creación. Por favor, espere un momento.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Rutas públicas
router.post('/verify-pin', sensitiveLimit, EmployeeController.verifyPin);

// Rutas protegidas - requieren autenticación de empresa
router.use(authenticateToken);
router.use(requireCompanyUser);

// Rutas para empleados (autenticación de empleado) - deben ir antes que las rutas con :id
router.use('/me', requireEmployee);
router.get('/me/daily-schedule/:date', EmployeeController.getMyDailySchedule);
router.get('/me/weekly-schedule/:startDate', EmployeeController.getMyWeeklySchedule);
router.put('/me/password', sensitiveLimit, EmployeeController.changePassword);

// Gestión de empleados
router.post('/', createLimit, EmployeeController.createEmployee);
router.get('/', EmployeeController.getEmployees);
router.get('/:id', EmployeeController.getEmployee);
router.put('/:id', EmployeeController.updateEmployee);
router.delete('/:id', EmployeeController.deleteEmployee);

// Gestión de horarios de empleados
router.get('/:id/schedules', EmployeeController.getEmployeeSchedules);
router.post('/:id/schedules', EmployeeController.assignSchedules);
router.post('/:id/assign-schedule', EmployeeController.assignSchedule);

// Gestión de asignaciones de horarios individuales
router.delete('/employee-schedules/:id', EmployeeController.removeEmployeeSchedule);

// Horarios diarios y semanales
router.get('/:id/daily-schedule/:date', EmployeeController.getDailySchedule);
router.get('/:id/weekly-schedule/:startDate', EmployeeController.getWeeklySchedule);

// Gestión de PIN y contraseñas
router.post('/reset-pin', sensitiveLimit, EmployeeController.resetPin);

// Estadísticas
router.get('/stats/overview', EmployeeController.getEmployeeStats);

export default router;