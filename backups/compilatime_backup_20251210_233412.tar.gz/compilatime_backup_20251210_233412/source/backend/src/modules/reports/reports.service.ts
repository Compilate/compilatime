import { PrismaClient, TimeEntryType } from '@prisma/client';
import {
  ReportFilters,
  TimeReportData,
  AttendanceReportData,
  EmployeeSummaryReportData,
  MonthlyReportData,
  ReportResponse
} from '../types/reports.types';

const prisma = new PrismaClient();

class ReportsService {
  /**
   * Genera un reporte de horas trabajadas
   */
  async getTimeReport(filters: ReportFilters): Promise<ReportResponse<TimeReportData>> {
    try {
      const { companyId, employeeIds, startDate, endDate, groupBy = 'day' } = filters;
      
      // Construir where clause para TimeEntries
      const timeEntryWhere: any = {
        companyId,
        timestamp: {
          gte: new Date(startDate),
          lte: new Date(endDate)
        }
      };
      
      if (employeeIds && employeeIds.length > 0) {
        timeEntryWhere.employeeId = {
          in: employeeIds
        };
      }
      
      // Obtener todos los fichajes del período
      const timeEntries = await prisma.timeEntry.findMany({
        where: timeEntryWhere,
        include: {
          employee: {
            select: {
              id: true,
              name: true,
              dni: true
            }
          }
        },
        orderBy: [
          { employeeId: 'asc' },
          { timestamp: 'asc' }
        ]
      });
      
      // Agrupar y calcular horas
      const groupedData = this.groupTimeEntries(timeEntries, groupBy);
      
      // Calcular totales
      const totalMinutes = this.calculateTotalMinutes(timeEntries);
      
      const reportData: TimeReportData = {
        summary: {
          totalHours: this.formatMinutesForHours(totalMinutes),
          totalEntries: timeEntries.length,
          totalEmployees: new Set(timeEntries.map(e => e.employeeId)).size,
          period: {
            start: startDate,
            end: endDate
          }
        },
        details: groupedData,
        filters
      };
      
      return {
        success: true,
        data: reportData,
        message: 'Reporte de horas generado exitosamente'
      };
      
    } catch (error) {
      console.error('Error en getTimeReport:', error);
      return {
        success: false,
        message: 'Error al generar reporte de horas',
        error: error instanceof Error ? error.message : 'Error desconocido'
      };
    }
  }
  
  /**
   * Genera un reporte de asistencia
   */
  async getAttendanceReport(filters: ReportFilters): Promise<ReportResponse<AttendanceReportData>> {
    try {
      const { companyId, employeeIds, startDate, endDate } = filters;
      
      // Obtener empleados
      const employeeWhere: any = { companyId, active: true };
      if (employeeIds && employeeIds.length > 0) {
        employeeWhere.id = { in: employeeIds };
      }
      
      const employees = await prisma.employee.findMany({
        where: employeeWhere,
        include: {
          employeeSchedules: {
            include: {
              schedule: true
            }
          }
        }
      });
      
      // Para cada empleado, calcular asistencia en el período
      const attendanceDetails = await Promise.all(
        employees.map(async (employee) => {
          // Obtener fichajes del empleado en el período
          const timeEntries = await prisma.timeEntry.findMany({
            where: {
              employeeId: employee.id,
              timestamp: {
                gte: new Date(startDate),
                lte: new Date(endDate)
              }
            },
            orderBy: { timestamp: 'asc' }
          });
          
          // Calcular días trabajados, ausencias, tardanzas, etc.
          const workDays = this.calculateWorkDays(startDate, endDate, employee.employeeSchedules);
          const workedDays = this.calculateWorkedDays(timeEntries);
          const absences = workDays - workedDays;
          const lateEntries = this.calculateLateEntries(timeEntries, employee.employeeSchedules);
          
          return {
            employee: {
              id: employee.id,
              name: employee.name,
              dni: employee.dni
            },
            statistics: {
              workDays,
              workedDays,
              absences,
              attendanceRate: workDays > 0 ? (workedDays / workDays) * 100 : 0,
              lateEntries,
              totalHours: this.calculateTotalHours(timeEntries)
            }
          };
        })
      );
      
      // Calcular totales generales
      const totalWorkDays = attendanceDetails.reduce((sum, emp) => sum + emp.statistics.workDays, 0);
      const totalWorkedDays = attendanceDetails.reduce((sum, emp) => sum + emp.statistics.workedDays, 0);
      const totalAbsences = attendanceDetails.reduce((sum, emp) => sum + emp.statistics.absences, 0);
      const overallAttendanceRate = totalWorkDays > 0 ? (totalWorkedDays / totalWorkDays) * 100 : 0;
      
      const reportData: AttendanceReportData = {
        summary: {
          totalEmployees: employees.length,
          totalWorkDays,
          totalWorkedDays,
          totalAbsences,
          overallAttendanceRate,
          period: {
            start: startDate,
            end: endDate
          }
        },
        details: attendanceDetails,
        filters
      };
      
      return {
        success: true,
        data: reportData,
        message: 'Reporte de asistencia generado exitosamente'
      };
      
    } catch (error) {
      console.error('Error en getAttendanceReport:', error);
      return {
        success: false,
        message: 'Error al generar reporte de asistencia',
        error: error instanceof Error ? error.message : 'Error desconocido'
      };
    }
  }
  
  /**
   * Genera un reporte resumido por empleado
   */
  async getEmployeeSummaryReport(filters: ReportFilters): Promise<ReportResponse<EmployeeSummaryReportData>> {
    try {
      const { companyId, employeeIds, startDate, endDate } = filters;
      
      // Obtener empleados
      const employeeWhere: any = { companyId };
      if (employeeIds && employeeIds.length > 0) {
        employeeWhere.id = { in: employeeIds };
      }
      
      const employees = await prisma.employee.findMany({
        where: employeeWhere,
        include: {
          employeeSchedules: {
            include: {
              schedule: true
            }
          },
          timeEntries: {
            where: {
              timestamp: {
                gte: new Date(startDate),
                lte: new Date(endDate)
              }
            },
            orderBy: { timestamp: 'asc' }
          }
        }
      });
      
      // Procesar datos de cada empleado
      const employeeSummaries = employees.map(employee => {
        const timeEntries = employee.timeEntries;
        const totalHours = this.calculateTotalHours(timeEntries);
        const workDays = this.calculateWorkDays(startDate, endDate, employee.employeeSchedules);
        const workedDays = this.calculateWorkedDays(timeEntries);
        const attendanceRate = workDays > 0 ? (workedDays / workDays) * 100 : 0;
        const lateEntries = this.calculateLateEntries(timeEntries, employee.employeeSchedules);
        
        // Agrupar horas por tipo de turno
        const hoursBySchedule = this.calculateHoursBySchedule(timeEntries, employee.employeeSchedules);
        
        return {
          employee: {
            id: employee.id,
            name: employee.name,
            dni: employee.dni,
            active: employee.active
          },
          summary: {
            totalHours,
            workDays,
            workedDays,
            attendanceRate,
            lateEntries,
            averageHoursPerDay: workedDays > 0 ? totalHours / workedDays : 0
          },
          hoursBySchedule
        };
      });
      
      // Ordenar por nombre
      employeeSummaries.sort((a, b) => a.employee.name.localeCompare(b.employee.name));
      
      const reportData: EmployeeSummaryReportData = {
        summary: {
          totalEmployees: employees.length,
          totalHours: employeeSummaries.reduce((sum, emp) => sum + emp.summary.totalHours, 0),
          averageAttendanceRate: employeeSummaries.reduce((sum, emp) => sum + emp.summary.attendanceRate, 0) / employees.length,
          period: {
            start: startDate,
            end: endDate
          }
        },
        details: employeeSummaries,
        filters
      };
      
      return {
        success: true,
        data: reportData,
        message: 'Reporte resumido por empleado generado exitosamente'
      };
      
    } catch (error) {
      console.error('Error en getEmployeeSummaryReport:', error);
      return {
        success: false,
        message: 'Error al generar reporte resumido por empleado',
        error: error instanceof Error ? error.message : 'Error desconocido'
      };
    }
  }
  
  /**
   * Genera un reporte mensual consolidado
   */
  async getMonthlyReport(filters: ReportFilters): Promise<ReportResponse<MonthlyReportData>> {
    try {
      const { startDate, endDate } = filters;
      
      // Obtener datos del período
      const timeReport = await this.getTimeReport(filters);
      const attendanceReport = await this.getAttendanceReport(filters);
      const employeeSummaryReport = await this.getEmployeeSummaryReport(filters);
      
      if (!timeReport.success || !attendanceReport.success || !employeeSummaryReport.success) {
        throw new Error('Error al generar sub-reportes para el reporte mensual');
      }
      
      // Calcular estadísticas adicionales
      const start = new Date(startDate);
      const end = new Date(endDate);
      const daysInPeriod = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      
      // Obtener distribución por día de la semana
      const dayOfWeekDistribution = this.calculateDayOfWeekDistribution(
        timeReport.data?.details || [],
        start,
        end
      );
      
      // Obtener horas por tipo de turno
      const hoursByScheduleType = this.calculateHoursByScheduleType(employeeSummaryReport.data?.details || []);
      
      const reportData: MonthlyReportData = {
        periodInfo: {
          startDate,
          endDate,
          daysInPeriod,
          workDays: this.countWorkDays(start, end)
        },
        timeSummary: timeReport.data?.summary || {
          totalHours: "0:00",
          totalEntries: 0,
          totalEmployees: 0,
          period: { start: startDate, end: endDate }
        },
        attendanceSummary: attendanceReport.data?.summary || {
          totalEmployees: 0,
          totalWorkDays: 0,
          totalWorkedDays: 0,
          totalAbsences: 0,
          overallAttendanceRate: 0,
          period: { start: startDate, end: endDate }
        },
        employeeSummaries: employeeSummaryReport.data?.summary || {
          totalEmployees: 0,
          totalHours: 0,
          averageAttendanceRate: 0,
          period: { start: startDate, end: endDate }
        },
        analytics: {
          dayOfWeekDistribution,
          hoursByScheduleType,
          peakDays: this.findPeakDays(timeReport.data?.details || []),
          trends: this.calculateTrends(timeReport.data?.details || [])
        },
        details: {
          timeDetails: timeReport.data?.details || [],
          attendanceDetails: attendanceReport.data?.details || [],
          employeeDetails: employeeSummaryReport.data?.details || []
        },
        filters
      };
      
      return {
        success: true,
        data: reportData,
        message: 'Reporte mensual generado exitosamente'
      };
      
    } catch (error) {
      console.error('Error en getMonthlyReport:', error);
      return {
        success: false,
        message: 'Error al generar reporte mensual',
        error: error instanceof Error ? error.message : 'Error desconocido'
      };
    }
  }
  
  /**
   * Agrupa las entradas de tiempo según el criterio especificado
   */
  private groupTimeEntries(timeEntries: any[], _groupBy: string): any[] {
    // Implementación simplificada - agrupar por día
    const grouped: { [key: string]: any[] } = {};
    
    timeEntries.forEach(entry => {
      const date = entry.timestamp.toISOString().split('T')[0];
      if (!grouped[date]) {
        grouped[date] = [];
      }
      grouped[date].push(entry);
    });
    
    return Object.entries(grouped).map(([date, entries]) => ({
      date,
      entries,
      totalHours: this.calculateTotalHours(entries),
      employeeCount: new Set(entries.map((e: any) => e.employeeId)).size
    }));
  }
  
  /**
   * Calcula los días laborables para un empleado en un período
   */
  private calculateWorkDays(startDate: string, endDate: string, _employeeSchedules: any[]): number {
    // Implementación simplificada - contar días de semana (lunes a viernes)
    const start = new Date(startDate);
    const end = new Date(endDate);
    let workDays = 0;
    
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dayOfWeek = d.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 5) { // Lunes a viernes
        workDays++;
      }
    }
    
    return workDays;
  }
  
  /**
   * Calcula los días trabajados basados en las entradas de tiempo
   */
  private calculateWorkedDays(timeEntries: any[]): number {
    const workedDates = new Set<string>();
    
    timeEntries.forEach(entry => {
      if (entry.type === 'IN') {
        workedDates.add(entry.timestamp.toISOString().split('T')[0]);
      }
    });
    
    return workedDates.size;
  }
  
  /**
   * Calcula las entradas tardías
   */
  private calculateLateEntries(timeEntries: any[], _employeeSchedules: any[]): number {
    // Implementación simplificada
    let lateCount = 0;
    
    timeEntries.forEach(entry => {
      if (entry.type === 'IN') {
        const entryTime = entry.timestamp.getHours();
        if (entryTime > 9) { // Después de las 9 AM se considera tardanza
          lateCount++;
        }
      }
    });
    
    return lateCount;
  }
  
  /**
   * Calcula el total de horas trabajadas
   */
  private calculateTotalHours(timeEntries: any[]): number {
    const totalMinutes = this.calculateTotalMinutes(timeEntries);
    return totalMinutes / 60; // Convertir a horas
  }
  
  /**
   * Calcula el total de minutos trabajados
   */
  private calculateTotalMinutes(timeEntries: any[]): number {
    let totalMinutes = 0;
    const sortedEntries = [...timeEntries].sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    for (let i = 0; i < sortedEntries.length; i++) {
      if (sortedEntries[i].type === 'IN') {
        // Buscar el OUT correspondiente
        for (let j = i + 1; j < sortedEntries.length; j++) {
          if (sortedEntries[j].type === 'OUT') {
            totalMinutes += this.calculateWorkedMinutesForDay([sortedEntries[i], sortedEntries[j]]);
            break;
          }
        }
      }
    }
    
    return totalMinutes;
  }
  
  /**
   * Calcula horas por tipo de horario
   */
  private calculateHoursBySchedule(timeEntries: any[], employeeSchedules: any[]): any[] {
    // Implementación simplificada
    const scheduleHours: { [key: string]: number } = {};
    
    employeeSchedules.forEach(es => {
      scheduleHours[es.schedule.name] = 0;
    });
    
    // Asignar horas a horarios (lógica simplificada)
    let currentSchedule = employeeSchedules[0];
    if (currentSchedule) {
      scheduleHours[currentSchedule.schedule.name] = this.calculateTotalHours(timeEntries);
    }
    
    return Object.entries(scheduleHours).map(([scheduleName, hours]) => ({
      scheduleName,
      hours
    }));
  }
  
  /**
   * Calcula distribución por día de la semana
   */
  private calculateDayOfWeekDistribution(groupedData: any[], _startDate: Date, _endDate: Date): any[] {
    const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    const distribution = dayNames.map(day => ({ day, hours: 0, entries: 0 }));
    
    groupedData.forEach((dayData: any) => {
      const date = new Date(dayData.date);
      const dayOfWeek = date.getDay();
      distribution[dayOfWeek].hours += dayData.totalHours;
      distribution[dayOfWeek].entries += dayData.entries.length;
    });
    
    return distribution;
  }
  
  /**
   * Calcula horas por tipo de horario
   */
  private calculateHoursByScheduleType(employeeDetails: any[]): any[] {
    const scheduleTypes: { [key: string]: number } = {};
    
    employeeDetails.forEach((employee: any) => {
      employee.hoursBySchedule.forEach((schedule: any) => {
        if (!scheduleTypes[schedule.scheduleName]) {
          scheduleTypes[schedule.scheduleName] = 0;
        }
        scheduleTypes[schedule.scheduleName] += schedule.hours;
      });
    });
    
    return Object.entries(scheduleTypes).map(([scheduleName, hours]) => ({
      scheduleName,
      hours
    }));
  }
  
  /**
   * Encuentra los días con mayor actividad
   */
  private findPeakDays(groupedData: any[]): any[] {
    return groupedData
      .sort((a, b) => b.totalHours - a.totalHours)
      .slice(0, 5)
      .map(day => ({
        date: day.date,
        hours: day.totalHours,
        employeeCount: day.employeeCount
      }));
  }
  
  /**
   * Calcula tendencias (implementación básica)
   */
  private calculateTrends(groupedData: any[]): any {
    if (groupedData.length < 2) {
      return { trend: 'insufficient_data', change: 0 };
    }
    
    const firstHalf = groupedData.slice(0, Math.floor(groupedData.length / 2));
    const secondHalf = groupedData.slice(Math.floor(groupedData.length / 2));
    
    const firstHalfAvg = firstHalf.reduce((sum, day) => sum + day.totalHours, 0) / firstHalf.length;
    const secondHalfAvg = secondHalf.reduce((sum, day) => sum + day.totalHours, 0) / secondHalf.length;
    
    const change = ((secondHalfAvg - firstHalfAvg) / firstHalfAvg) * 100;
    
    return {
      trend: change > 5 ? 'increasing' : change < -5 ? 'decreasing' : 'stable',
      change: Math.round(change * 100) / 100
    };
  }
  
  /**
   * Cuenta días laborables en un rango de fechas
   */
  private countWorkDays(startDate: Date, endDate: Date): number {
    let workDays = 0;
    for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
      const dayOfWeek = d.getDay();
      if (dayOfWeek >= 1 && dayOfWeek <= 5) { // Lunes a viernes
        workDays++;
      }
    }
    return workDays;
  }
  
  /**
   * Calcula minutos trabajados para un conjunto de entradas
   */
  private calculateWorkedMinutesForDay(entries: any[]): number {
    let totalMinutes = 0;
    let inTime: Date | null = null;

    for (const entry of entries) {
      if (entry.type === TimeEntryType.IN) {
        inTime = entry.timestamp;
      } else if (entry.type === TimeEntryType.OUT && inTime) {
        totalMinutes += (entry.timestamp.getTime() - inTime.getTime()) / (1000 * 60);
        inTime = null;
      }
    }

    return totalMinutes;
  }
  
  /**
   * Formatea minutos a formato HH:MM
   */
  private formatMinutesForHours(minutes: number): string {
    const hours = Math.floor(minutes / 60);
    const mins = Math.round(minutes % 60);
    return `${hours}:${mins.toString().padStart(2, '0')}`;
  }
}

export const reportsService = new ReportsService();