import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import CompanyController from './company.controller';
import { authenticateToken, requireCompanyUser } from '../../middlewares/authMiddleware';

const router = Router();

// Rate limiting para creación de empresas
const createCompanyLimit = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: 3, // máximo 3 empresas por IP en 15 minutos
    message: {
        success: false,
        message: 'Demasiados intentos de creación de empresas. Por favor, inténtelo más tarde.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Rate limiting para invitaciones
const inviteLimit = rateLimit({
    windowMs: 60 * 1000, // 1 minuto
    max: 5, // máximo 5 invitaciones por minuto
    message: {
        success: false,
        message: 'Demasiadas invitaciones. Por favor, espere un momento.',
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Rutas públicas
router.post('/', createCompanyLimit, CompanyController.createCompany);
router.get('/slug/:slug', CompanyController.getCompanyBySlug);
router.post('/activate-user', CompanyController.activateUser);

// Rutas protegidas - requieren autenticación de empresa
router.use(authenticateToken);
router.use(requireCompanyUser);

// Gestión de empresas
router.get('/:id', CompanyController.getCompany);
router.put('/:id', CompanyController.updateCompany);
router.put('/:id/config', CompanyController.updateConfig);

// Gestión de usuarios de la empresa
router.get('/:id/users', CompanyController.getUsers);
router.post('/:id/users/invite', inviteLimit, CompanyController.inviteUser);
router.put('/:id/users/:userId/deactivate', CompanyController.deactivateUser);
router.delete('/:id/users/:userId', CompanyController.deleteUser);

// Gestión de suscripción
router.get('/:id/subscription', CompanyController.getSubscription);
router.put('/:id/subscription', CompanyController.updateSubscription);

export default router;