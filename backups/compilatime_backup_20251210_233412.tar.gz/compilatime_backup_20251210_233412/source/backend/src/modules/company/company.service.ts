import { PrismaClient, Company, CompanyUser } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { cache } from '../../config/redis';
import { sendEmail } from '../../config/email';
import { env } from '../../config/env';

const prisma = new PrismaClient();

// Esquemas de validación
const createCompanySchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
    slug: z.string().min(2, 'El código debe tener al menos 2 caracteres')
        .regex(/^[a-z0-9-]+$/, 'El código solo puede contener letras minúsculas, números y guiones'),
    email: z.string().email('Email inválido'),
    adminName: z.string().min(2, 'El nombre del administrador debe tener al menos 2 caracteres'),
    adminEmail: z.string().email('Email del administrador inválido'),
    adminPassword: z.string().min(6, 'La contraseña debe tener al menos 6 caracteres'),
    plan: z.enum(['FREE', 'BASIC', 'PRO', 'ENTERPRISE']).default('BASIC'),
});

const updateCompanySchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres').optional(),
    email: z.string().email('Email inválido').optional(),
    phone: z.string().optional(),
    address: z.string().optional(),
    city: z.string().optional(),
    province: z.string().optional(),
    postalCode: z.string().optional(),
    country: z.string().optional(),
    taxId: z.string().optional(),
    logo: z.string().url('URL del logo inválida').optional(),
    website: z.string().url('URL del sitio web inválida').optional(),
    description: z.string().optional(),
});

const updateCompanyConfigSchema = z.object({
    timezone: z.string().optional(),
    dateFormat: z.string().optional(),
    timeFormat: z.enum(['12h', '24h']).optional(),
    currency: z.string().optional(),
    language: z.string().optional(),
    workingDays: z.array(z.number()).optional(),
    workingHours: z.object({
        start: z.string(),
        end: z.string(),
    }).optional(),
    overtimeRules: z.object({
        enabled: z.boolean(),
        dailyThreshold: z.number(),
        weeklyThreshold: z.number(),
        rate: z.number(),
    }).optional(),
    notifications: z.object({
        emailEnabled: z.boolean(),
        pushEnabled: z.boolean(),
        smsEnabled: z.boolean(),
    }).optional(),
    security: z.object({
        passwordMinLength: z.number(),
        sessionTimeout: z.number(),
        maxLoginAttempts: z.number(),
        twoFactorEnabled: z.boolean(),
    }).optional(),
});

const inviteUserSchema = z.object({
    name: z.string().min(2, 'El nombre debe tener al menos 2 caracteres'),
    email: z.string().email('Email inválido'),
    role: z.enum(['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'SUPERVISOR', 'HR']),
    permissions: z.array(z.string()).optional(),
});

// Tipos
type CreateCompanyData = z.infer<typeof createCompanySchema>;
type UpdateCompanyData = z.infer<typeof updateCompanySchema>;
type UpdateCompanyConfigData = z.infer<typeof updateCompanyConfigSchema>;
type InviteUserData = z.infer<typeof inviteUserSchema>;

// Servicio de gestión de empresas
export class CompanyService {
    // Crear nueva empresa con usuario administrador
    static async createCompany(data: CreateCompanyData): Promise<Company> {
        try {
            // Validar datos
            const validatedData = createCompanySchema.parse(data);

            // Verificar si el slug ya existe
            const existingCompany = await prisma.company.findUnique({
                where: { slug: validatedData.slug },
            });

            if (existingCompany) {
                throw new Error('El código de empresa ya está en uso');
            }

            // Verificar si el email de la empresa ya existe
            const existingEmail = await prisma.company.findUnique({
                where: { email: validatedData.email },
            });

            if (existingEmail) {
                throw new Error('El email de la empresa ya está en uso');
            }

            // Crear la empresa
            const company = await prisma.company.create({
                data: {
                    name: validatedData.name,
                    slug: validatedData.slug,
                    email: validatedData.email,
                    settings: {
                        plan: validatedData.plan,
                        maxEmployees: this.getMaxEmployeesByPlan(validatedData.plan),
                        features: this.getFeaturesByPlan(validatedData.plan),
                        timezone: 'Europe/Madrid',
                        dateFormat: 'DD/MM/YYYY',
                        timeFormat: '24h',
                        currency: 'EUR',
                        language: 'es',
                        workingDays: [1, 2, 3, 4, 5], // Lunes a Viernes
                        workingHours: {
                            start: '09:00',
                            end: '18:00',
                        },
                        overtimeRules: {
                            enabled: true,
                            dailyThreshold: 8,
                            weeklyThreshold: 40,
                            rate: 1.25,
                        },
                        notifications: {
                            emailEnabled: true,
                            pushEnabled: false,
                            smsEnabled: false,
                        },
                        security: {
                            passwordMinLength: 6,
                            sessionTimeout: 8,
                            maxLoginAttempts: 5,
                            twoFactorEnabled: false,
                        },
                    },
                },
            });

            // Crear usuario administrador
            const hashedPassword = await bcrypt.hash(validatedData.adminPassword, 10);
            await prisma.companyUser.create({
                data: {
                    companyId: company.id,
                    name: validatedData.adminName,
                    email: validatedData.adminEmail,
                    passwordHash: hashedPassword,
                    role: 'ADMIN',
                    active: true,
                },
            });

            // Enviar email de bienvenida
            await this.sendWelcomeEmail(company, validatedData.adminEmail, validatedData.adminPassword);

            // Limpiar caché
            await cache.clearPattern('company:*');

            console.log(`✅ Empresa creada: ${company.name} (${company.slug})`);
            return company;
        } catch (error) {
            console.error('❌ Error creando empresa:', error);
            throw error;
        }
    }

    // Obtener empresa por ID
    static async getCompanyById(companyId: string): Promise<Company | null> {
        try {
            // Intentar obtener desde caché
            const cacheKey = `company:${companyId}`;
            const cached = await cache.get(cacheKey);

            if (cached) {
                return JSON.parse(cached);
            }

            const company = await prisma.company.findUnique({
                where: { id: companyId },
                include: {
                    _count: {
                        select: {
                            companyUsers: true,
                            employees: true,
                        },
                    },
                },
            });

            if (company) {
                // Guardar en caché por 1 hora
                await cache.set(cacheKey, JSON.stringify(company), 3600);
            }

            return company;
        } catch (error) {
            console.error(`❌ Error obteniendo empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Obtener empresa por slug
    static async getCompanyBySlug(slug: string): Promise<Company | null> {
        try {
            // Intentar obtener desde caché
            const cacheKey = `company:slug:${slug}`;
            const cached = await cache.get(cacheKey);

            if (cached) {
                return JSON.parse(cached);
            }

            const company = await prisma.company.findUnique({
                where: { slug },
                include: {
                    _count: {
                        select: {
                            companyUsers: true,
                            employees: true,
                        },
                    },
                },
            });

            if (company) {
                // Guardar en caché por 1 hora
                await cache.set(cacheKey, JSON.stringify(company), 3600);
            }

            return company;
        } catch (error) {
            console.error(`❌ Error obteniendo empresa por slug ${slug}:`, error);
            throw error;
        }
    }

    // Actualizar datos de la empresa
    static async updateCompany(companyId: string, data: UpdateCompanyData): Promise<Company> {
        try {
            // Validar datos
            const validatedData = updateCompanySchema.parse(data);

            // Verificar si el email ya está en uso por otra empresa
            if (validatedData.email) {
                const existingEmail = await prisma.company.findFirst({
                    where: {
                        email: validatedData.email,
                        id: { not: companyId },
                    },
                });

                if (existingEmail) {
                    throw new Error('El email ya está en uso por otra empresa');
                }
            }

            const company = await prisma.company.update({
                where: { id: companyId },
                data: validatedData,
            });

            // Limpiar caché
            await cache.clearPattern(`company:${companyId}*`);
            await cache.clearPattern(`company:slug:${company.slug}*`);

            console.log(`✅ Empresa actualizada: ${company.name}`);
            return company;
        } catch (error) {
            console.error(`❌ Error actualizando empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Actualizar configuración de la empresa
    static async updateCompanyConfig(companyId: string, data: UpdateCompanyConfigData): Promise<Company> {
        try {
            // Validar datos
            const validatedData = updateCompanyConfigSchema.parse(data);

            // Actualizar configuración en el campo settings de la empresa
            const company = await prisma.company.update({
                where: { id: companyId },
                data: {
                    settings: validatedData,
                },
            });

            // Limpiar caché
            await cache.clearPattern(`company:${companyId}*`);

            console.log(`✅ Configuración actualizada para empresa ${companyId}`);
            return company;
        } catch (error) {
            console.error(`❌ Error actualizando configuración de empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Obtener usuarios de la empresa
    static async getCompanyUsers(companyId: string, page: number = 1, limit: number = 20) {
        try {
            const skip = (page - 1) * limit;

            const [users, total] = await Promise.all([
                prisma.companyUser.findMany({
                    where: { companyId },
                    skip,
                    take: limit,
                    orderBy: { createdAt: 'desc' },
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                        active: true,
                        lastLoginAt: true,
                        createdAt: true,
                    },
                }),
                prisma.companyUser.count({
                    where: { companyId },
                }),
            ]);

            return {
                users,
                pagination: {
                    page,
                    limit,
                    total,
                    pages: Math.ceil(total / limit),
                },
            };
        } catch (error) {
            console.error(`❌ Error obteniendo usuarios de empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Invitar usuario a la empresa (simplificado - sin sistema de invitaciones)
    static async inviteUser(companyId: string, data: InviteUserData): Promise<CompanyUser> {
        try {
            // Validar datos
            const validatedData = inviteUserSchema.parse(data);

            // Verificar si el email ya existe en la empresa
            const existingUser = await prisma.companyUser.findFirst({
                where: {
                    companyId,
                    email: validatedData.email,
                },
            });

            if (existingUser) {
                throw new Error('El email ya está registrado en esta empresa');
            }

            // Generar contraseña temporal
            const tempPassword = Math.random().toString(36).slice(-8);
            const passwordHash = await bcrypt.hash(tempPassword, 10);

            // Crear usuario
            const user = await prisma.companyUser.create({
                data: {
                    companyId,
                    name: validatedData.name,
                    email: validatedData.email,
                    role: validatedData.role as any,
                    passwordHash,
                    active: true,
                },
            });

            // Enviar email de bienvenida
            await this.sendUserWelcomeEmail(user.email, await this.getCompanyName(companyId), tempPassword);

            console.log(`✅ Usuario invitado: ${user.email} a empresa ${companyId}`);
            return user;
        } catch (error) {
            console.error(`❌ Error invitando usuario a empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Desactivar usuario
    static async deactivateUser(companyId: string, userId: string): Promise<CompanyUser> {
        try {
            const user = await prisma.companyUser.update({
                where: {
                    id: userId,
                    companyId,
                },
                data: {
                    active: false,
                },
            });

            console.log(`✅ Usuario desactivado: ${user.email}`);
            return user;
        } catch (error) {
            console.error(`❌ Error desactivando usuario ${userId}:`, error);
            throw error;
        }
    }

    // Eliminar usuario
    static async deleteUser(companyId: string, userId: string): Promise<void> {
        try {
            await prisma.companyUser.delete({
                where: {
                    id: userId,
                    companyId,
                },
            });

            console.log(`✅ Usuario eliminado: ${userId}`);
        } catch (error) {
            console.error(`❌ Error eliminando usuario ${userId}:`, error);
            throw error;
        }
    }

    // Obtener suscripción de la empresa
    static async getCompanySubscription(companyId: string): Promise<any | null> {
        try {
            // Por ahora, devolver información básica de la empresa
            // En el futuro se puede implementar un modelo de suscripción separado
            const company = await prisma.company.findUnique({
                where: { id: companyId },
                select: {
                    id: true,
                    name: true,
                    settings: true,
                },
            });

            return company;
        } catch (error) {
            console.error(`❌ Error obteniendo suscripción de empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Actualizar suscripción
    static async updateSubscription(companyId: string, plan: string): Promise<Company> {
        try {
            // Actualizar información del plan en los settings de la empresa
            const company = await prisma.company.update({
                where: { id: companyId },
                data: {
                    settings: {
                        plan,
                        maxEmployees: this.getMaxEmployeesByPlan(plan as any),
                        features: this.getFeaturesByPlan(plan as any),
                    },
                },
            });

            console.log(`✅ Suscripción actualizada para empresa ${companyId}: ${plan}`);
            return company;
        } catch (error) {
            console.error(`❌ Error actualizando suscripción de empresa ${companyId}:`, error);
            throw error;
        }
    }

    // Métodos auxiliares
    private static getMaxEmployeesByPlan(plan: string): number {
        const limits = {
            FREE: 5,
            BASIC: 20,
            PRO: 100,
            ENTERPRISE: -1, // Ilimitado
        };
        return limits[plan as keyof typeof limits] || 5;
    }

    private static getFeaturesByPlan(plan: string): string[] {
        const features = {
            FREE: ['basic_time_tracking', 'basic_reports'],
            BASIC: ['basic_time_tracking', 'basic_reports', 'email_notifications', 'employee_management'],
            PRO: ['basic_time_tracking', 'basic_reports', 'email_notifications', 'employee_management', 'advanced_reports', 'overtime_calculation', 'api_access'],
            ENTERPRISE: ['basic_time_tracking', 'basic_reports', 'email_notifications', 'employee_management', 'advanced_reports', 'overtime_calculation', 'api_access', 'custom_integrations', 'priority_support', 'white_label'],
        };
        return features[plan as keyof typeof features] || features.FREE;
    }

    private static async getCompanyName(companyId: string): Promise<string> {
        const company = await prisma.company.findUnique({
            where: { id: companyId },
            select: { name: true }
        });
        return company?.name || 'la empresa';
    }

    private static async sendWelcomeEmail(company: Company, adminEmail: string, adminPassword: string): Promise<void> {
        try {
            const subject = 'Bienvenido a CompilaTime';
            const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #1E40AF; color: white; padding: 20px; text-align: center;">
            <h1>🎉 Bienvenido a CompilaTime</h1>
          </div>
          <div style="padding: 20px;">
            <h2>¡Tu empresa ha sido creada con éxito!</h2>
            <p>Hola,</p>
            <p>Tu empresa <strong>${company.name}</strong> ha sido configurada correctamente en CompilaTime.</p>
            <div style="background: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <h3>📋 Datos de acceso:</h3>
              <p><strong>Código de empresa:</strong> ${company.slug}</p>
              <p><strong>Email:</strong> ${adminEmail}</p>
              <p><strong>Contraseña:</strong> ${adminPassword}</p>
            </div>
            <p>Puedes acceder al panel de administración haciendo clic en el siguiente botón:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${env.FRONTEND_URL}/empresa/login" style="background: #1E40AF; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                Acceder al Panel
              </a>
            </div>
            <p>Recomendamos cambiar tu contraseña después del primer inicio de sesión.</p>
            <p>Si tienes alguna pregunta, no dudes en contactarnos.</p>
            <p>Saludos,<br>El equipo de CompilaTime</p>
          </div>
          <div style="background: #f3f4f6; padding: 20px; text-align: center; font-size: 12px; color: #666;">
            <p>© 2024 CompilaTime. Todos los derechos reservados.</p>
          </div>
        </div>
      `;

            await sendEmail({ to: adminEmail, subject, html });
        } catch (error) {
            console.error('❌ Error enviando email de bienvenida:', error);
        }
    }

    private static async sendUserWelcomeEmail(email: string, companyName: string, tempPassword: string): Promise<void> {
        try {
            const subject = 'Bienvenido al equipo';
            const html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: #1E40AF; color: white; padding: 20px; text-align: center;">
            <h1>🎉 ¡Bienvenido al equipo!</h1>
          </div>
          <div style="padding: 20px;">
            <h2>Tu cuenta está lista</h2>
            <p>Hola,</p>
            <p>¡Felicidades! Tu cuenta en CompilaTime ha sido activada correctamente.</p>
            <p>Ya formas parte del equipo de <strong>${companyName}</strong>.</p>
            <div style="background: #f3f4f6; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <h3>📋 Datos de acceso:</h3>
              <p><strong>Email:</strong> ${email}</p>
              <p><strong>Contraseña temporal:</strong> ${tempPassword}</p>
            </div>
            <p>Ya puedes acceder al panel de administración y empezar a utilizar todas las funcionalidades.</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${env.FRONTEND_URL}/empresa/login" style="background: #1E40AF; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                Acceder al Panel
              </a>
            </div>
            <p>Recomendamos cambiar tu contraseña después del primer inicio de sesión.</p>
            <p>Si tienes alguna pregunta, contacta con tu administrador.</p>
            <p>Saludos,<br>El equipo de CompilaTime</p>
          </div>
          <div style="background: #f3f4f6; padding: 20px; text-align: center; font-size: 12px; color: #666;">
            <p>© 2024 CompilaTime. Todos los derechos reservados.</p>
          </div>
        </div>
      `;

            await sendEmail({ to: email, subject, html });
        } catch (error) {
            console.error('❌ Error enviando email de bienvenida al usuario:', error);
        }
    }
}

export default CompanyService;