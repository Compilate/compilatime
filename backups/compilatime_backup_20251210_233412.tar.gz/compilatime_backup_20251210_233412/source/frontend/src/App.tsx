import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { useAuth } from './contexts/AuthContext';

// Layouts
import BackofficeLayout from './routes/BackofficeLayout';
import EmployeeLayout from './routes/EmployeeLayout';

// Páginas públicas
import LoginEmpresaPage from './pages/backoffice/LoginEmpresaPage';
import FicharPage from './pages/employee/FicharPage';
import LoginEmpleadoPage from './pages/employee/LoginEmpleadoPage';

// Páginas del backoffice
import DashboardEmpresaPage from './pages/backoffice/DashboardEmpresaPage';
import EmpleadosPage from './pages/backoffice/EmpleadosPage';
import HorariosPage from './pages/backoffice/HorariosPage';
import EmpleadoHorariosPage from './pages/backoffice/EmpleadoHorariosPage';
import RegistrosPage from './pages/backoffice/RegistrosPage';
import ReportesPage from './pages/backoffice/ReportesPage';

// Páginas de empleado
import PerfilEmpleadoPage from './pages/employee/PerfilEmpleadoPage';
import MisRegistrosPage from './pages/employee/MisRegistrosPage';

// Componentes
import Loader from './components/common/Loader';

// Componente de protección de rutas
const ProtectedRoute: React.FC<{ children: React.ReactNode; requiredRole?: string }> = ({
    children,
    requiredRole
}) => {
    const { isAuthenticated, userRole, loading } = useAuth();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader size="lg" text="Cargando..." />
            </div>
        );
    }

    if (!isAuthenticated) {
        return <Navigate to="/empresa/login" replace />;
    }

    if (requiredRole && userRole !== requiredRole) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-2xl font-bold text-gray-900 mb-2">Acceso Denegado</h1>
                    <p className="text-gray-600">No tienes permisos para acceder a esta página.</p>
                </div>
            </div>
        );
    }

    return <>{children}</>;
};

// Componente de protección para rutas de empleado
const EmployeeProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { isAuthenticated, employee, loading } = useAuth();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader size="lg" text="Cargando..." />
            </div>
        );
    }

    if (!isAuthenticated || !employee) {
        return <Navigate to="/empleado/login" replace />;
    }

    return <>{children}</>;
};

// Componente App interno que usa el contexto
const AppContent: React.FC = () => {
    const { loading } = useAuth();

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader size="lg" text="Iniciando aplicación..." />
            </div>
        );
    }

    return (
        <Router>
            <div className="App">
                <Routes>
                    {/* Rutas públicas */}
                    <Route path="/empresa/login" element={<LoginEmpresaPage />} />
                    <Route path="/empleado/fichar" element={<FicharPage />} />
                    <Route path="/empleado/login" element={<LoginEmpleadoPage />} />

                    {/* Rutas del backoffice (protegidas) */}
                    <Route
                        path="/empresa"
                        element={
                            <ProtectedRoute>
                                <BackofficeLayout />
                            </ProtectedRoute>
                        }
                    >
                        <Route index element={<Navigate to="/empresa/dashboard" replace />} />
                        <Route path="dashboard" element={<DashboardEmpresaPage />} />
                        <Route path="empleados" element={<EmpleadosPage />} />
                        <Route path="horarios" element={<HorariosPage />} />
                        <Route path="empleados/:employeeId/horarios" element={<EmpleadoHorariosPage />} />
                        <Route path="registros" element={<RegistrosPage />} />
                        <Route path="reportes" element={<ReportesPage />} />
                    </Route>

                    {/* Rutas de empleado (protegidas) */}
                    <Route
                        path="/empleado"
                        element={
                            <EmployeeProtectedRoute>
                                <EmployeeLayout />
                            </EmployeeProtectedRoute>
                        }
                    >
                        <Route index element={<Navigate to="/empleado/perfil" replace />} />
                        <Route path="perfil" element={<PerfilEmpleadoPage />} />
                        <Route path="mis-registros" element={<MisRegistrosPage />} />
                    </Route>

                    {/* Redirección por defecto */}
                    <Route path="/" element={<Navigate to="/empresa/login" replace />} />

                    {/* Página 404 */}
                    <Route
                        path="*"
                        element={
                            <div className="min-h-screen flex items-center justify-center">
                                <div className="text-center">
                                    <h1 className="text-4xl font-bold text-gray-900 mb-4">404</h1>
                                    <p className="text-gray-600 mb-4">Página no encontrada</p>
                                    <a
                                        href="/empresa/login"
                                        className="text-primary-600 hover:text-primary-800"
                                    >
                                        Ir al inicio
                                    </a>
                                </div>
                            </div>
                        }
                    />
                </Routes>
            </div>
        </Router>
    );
};

// Componente App principal que envuelve con el AuthProvider
const App: React.FC = () => {
    return (
        <AuthProvider>
            <AppContent />
        </AuthProvider>
    );
};

export default App;