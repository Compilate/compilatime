import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { authApi } from '../../lib/api';
import Button from '../../components/common/Button';
import Input from '../../components/common/Input';
// import Loader from '../../components/common/Loader';

const LoginEmpleadoPage: React.FC = () => {
    const [formData, setFormData] = useState({
        companySlug: '',
        dni: '',
        pin: '',
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();
    const { isAuthenticated, employee, login, setEmployee, setError } = useAuth();

    // Redirigir si ya está autenticado
    React.useEffect(() => {
        if (isAuthenticated && employee) {
            navigate('/empleado/perfil');
        }
    }, [isAuthenticated, employee, navigate]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        // Limpiar error del campo cuando el usuario empieza a escribir
        if (errors[name]) {
            setErrors(prev => ({ ...prev, [name]: '' }));
        }
    };

    const validateForm = () => {
        const newErrors: Record<string, string> = {};

        if (!formData.companySlug.trim()) {
            newErrors.companySlug = 'El código de empresa es obligatorio';
        }

        if (!formData.dni.trim()) {
            newErrors.dni = 'El DNI es obligatorio';
        } else if (!/^[0-9]{8}[A-Z]$/i.test(formData.dni)) {
            newErrors.dni = 'El formato del DNI no es válido (8 números + 1 letra)';
        }

        if (!formData.pin.trim()) {
            newErrors.pin = 'El PIN es obligatorio';
        } else if (!/^\d{4}$/.test(formData.pin)) {
            newErrors.pin = 'El PIN debe tener 4 dígitos';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!validateForm()) return;

        setLoading(true);
        setError(null);

        try {
            console.log('LoginEmpleadoPage: Iniciando login con:', {
                companySlug: formData.companySlug,
                dni: formData.dni
            });

            const response = await authApi.employeeLogin(formData);

            if (response.success && response.data) {
                const data = response.data as any;
                const { user, company, accessToken } = data;

                console.log('LoginEmpleadoPage: Login exitoso:', {
                    user: user.name,
                    company: company?.name,
                    hasToken: !!accessToken
                });

                // Para login de empleado, usamos el employee como "user" y la company como null
                login(user as any, company, accessToken, '');
                setEmployee(user);
                navigate('/empleado/perfil');
            } else {
                setErrors({ general: response.error || 'Error al iniciar sesión' });
            }
        } catch (error: any) {
            console.error('Error de login:', error);
            setErrors({
                general: error.message || 'Error de conexión. Inténtalo de nuevo.'
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
            <div className="sm:mx-auto sm:w-full sm:max-w-md">
                <div className="flex justify-center">
                    <div className="w-16 h-16 bg-primary-600 rounded-xl flex items-center justify-center">
                        <span className="text-white font-bold text-2xl">CT</span>
                    </div>
                </div>
                <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
                    Acceso Empleado
                </h2>
                <p className="mt-2 text-center text-sm text-gray-600">
                    Accede a tu zona personal
                </p>
            </div>

            <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
                <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
                    {errors.general && (
                        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
                            <p className="text-sm text-red-600">{errors.general}</p>
                        </div>
                    )}

                    <form className="space-y-6" onSubmit={handleSubmit}>
                        <Input
                            label="Código de Empresa"
                            name="companySlug"
                            type="text"
                            value={formData.companySlug}
                            onChange={handleChange}
                            error={errors.companySlug}
                            placeholder="ej: demo"
                            required
                            leftIcon={
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                </svg>
                            }
                        />

                        <Input
                            label="DNI"
                            name="dni"
                            type="text"
                            value={formData.dni}
                            onChange={handleChange}
                            error={errors.dni}
                            placeholder="12345678A"
                            required
                            maxLength={9}
                            leftIcon={
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2" />
                                </svg>
                            }
                        />

                        <Input
                            label="PIN"
                            name="pin"
                            type="password"
                            value={formData.pin}
                            onChange={handleChange}
                            error={errors.pin}
                            placeholder="••••"
                            required
                            maxLength={4}
                            leftIcon={
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                </svg>
                            }
                        />

                        <div className="flex items-center justify-between">
                            <div className="flex items-center">
                                <input
                                    id="remember-me"
                                    name="remember-me"
                                    type="checkbox"
                                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                                />
                                <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
                                    Recordarme
                                </label>
                            </div>

                            <div className="text-sm">
                                <a href="#" className="font-medium text-primary-600 hover:text-primary-500">
                                    ¿Olvidaste tu PIN?
                                </a>
                            </div>
                        </div>

                        <Button
                            type="submit"
                            fullWidth
                            loading={loading}
                            className="py-3"
                        >
                            Iniciar Sesión
                        </Button>
                    </form>

                    <div className="mt-6">
                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <div className="w-full border-t border-gray-300" />
                            </div>
                            <div className="relative flex justify-center text-sm">
                                <span className="px-2 bg-white text-gray-500">¿Solo quieres fichar?</span>
                            </div>
                        </div>

                        <div className="mt-6 text-center">
                            <Link
                                to="/empleado/fichar"
                                className="font-medium text-primary-600 hover:text-primary-500"
                            >
                                Fichaje rápido
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginEmpleadoPage;